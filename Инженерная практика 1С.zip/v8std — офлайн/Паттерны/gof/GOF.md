---
tags: [v8std, patterns]
---

[Статья на v8std.ru](https://v8std.ru/patterns/gof/) · [Оглавление](../../v8std%20%E2%80%94%20%D0%BD%D0%B0%D1%87%D0%B0%D1%82%D1%8C%20%D0%B7%D0%B4%D0%B5%D1%81%D1%8C.md)

# GOF

`GOF` — это набор из 23 классических паттернов проектирования из книги *Design Patterns: Elements of Reusable Object-Oriented Software*.

## Как читать раздел

1. Сначала понять намерение паттерна, а не копировать форму.
2. Потом посмотреть, как эта идея раскладывается на объекты метаданных, общие модули, формы и обработчики в 1С.
3. И только после этого решать, нужен ли паттерн в прикладной задаче или достаточно более простого кода.

## Порождающие паттерны

| Паттерн | Коротко | Пример |
| --- | --- | --- |
| [Абстрактная фабрика](abstract-factory/%D0%90%D0%B1%D1%81%D1%82%D1%80%D0%B0%D0%BA%D1%82%D0%BD%D0%B0%D1%8F%20%D1%84%D0%B0%D0%B1%D1%80%D0%B8%D0%BA%D0%B0%20%28Abstract%20Factory%29.md) (`Abstract Factory`) | Создает семейства связанных объектов через единый интерфейс. | [AbstractFactory](https://github.com/zeegin/DesignPatterns/tree/master/AbstractFactory) |
| [Строитель](builder/%D0%A1%D1%82%D1%80%D0%BE%D0%B8%D1%82%D0%B5%D0%BB%D1%8C%20%28Builder%29.md) (`Builder`) | Разделяет процесс пошаговой сборки сложного объекта и его итоговое представление. | [Builder](https://github.com/zeegin/DesignPatterns/tree/master/Builder) |
| [Фабричный метод](factory-method/%D0%A4%D0%B0%D0%B1%D1%80%D0%B8%D1%87%D0%BD%D1%8B%D0%B9%20%D0%BC%D0%B5%D1%82%D0%BE%D0%B4%20%28Factory%20Method%29.md) (`Factory Method`) | Делегирует создание объектов специализированному методу или подклассу. | [FactoryMethod](https://github.com/zeegin/DesignPatterns/tree/master/FactoryMethod) |
| [Прототип](prototype/%D0%9F%D1%80%D0%BE%D1%82%D0%BE%D1%82%D0%B8%D0%BF%20%28Prototype%29.md) (`Prototype`) | Создает новые объекты копированием заранее настроенного экземпляра. | [Prototype](https://github.com/zeegin/DesignPatterns/tree/master/Prototype) |
| [Одиночка](singleton/%D0%9E%D0%B4%D0%B8%D0%BD%D0%BE%D1%87%D0%BA%D0%B0%20%28Singleton%29.md) (`Singleton`) | Ограничивает создание класса одним экземпляром и дает глобальную точку доступа. | [Singleton](https://github.com/zeegin/DesignPatterns/tree/master/Singleton) |

## Структурные паттерны

| Паттерн | Коротко | Пример |
| --- | --- | --- |
| [Адаптер](adapter/%D0%90%D0%B4%D0%B0%D0%BF%D1%82%D0%B5%D1%80%20%28Adapter%29.md) (`Adapter`) | Приводит несовместимый интерфейс к ожидаемому клиентом виду. | [Adapter](https://github.com/zeegin/DesignPatterns/tree/master/Adapter) |
| [Мост](bridge/%D0%9C%D0%BE%D1%81%D1%82%20%28Bridge%29.md) (`Bridge`) | Разделяет абстракцию и реализацию, чтобы их можно было развивать независимо. |  |
| [Компоновщик](composite/%D0%9A%D0%BE%D0%BC%D0%BF%D0%BE%D0%BD%D0%BE%D0%B2%D1%89%D0%B8%D0%BA%20%28Composite%29.md) (`Composite`) | Позволяет работать с одиночными объектами и их деревьями единообразно. |  |
| [Декоратор](decorator/%D0%94%D0%B5%D0%BA%D0%BE%D1%80%D0%B0%D1%82%D0%BE%D1%80%20%28Decorator%29.md) (`Decorator`) | Добавляет объекту поведение через обертку, не меняя исходный класс. |  |
| [Фасад](facade/%D0%A4%D0%B0%D1%81%D0%B0%D0%B4%20%28Facade%29.md) (`Facade`) | Дает простой внешний вход к сложной подсистеме. |  |
| [Приспособленец](flyweight/%D0%9F%D1%80%D0%B8%D1%81%D0%BF%D0%BE%D1%81%D0%BE%D0%B1%D0%BB%D0%B5%D0%BD%D0%B5%D1%86%20%28Flyweight%29.md) (`Flyweight`) | Выносит общую часть состояния, чтобы экономить память на большом числе однотипных объектов. |  |
| [Заместитель](proxy/%D0%97%D0%B0%D0%BC%D0%B5%D1%81%D1%82%D0%B8%D1%82%D0%B5%D0%BB%D1%8C%20%28Proxy%29.md) (`Proxy`) | Подставляет специальный объект вместо реального и контролирует доступ к нему. |  |

## Поведенческие паттерны

| Паттерн | Коротко | Пример |
| --- | --- | --- |
| [Цепочка обязанностей](chain-of-responsibility/%D0%A6%D0%B5%D0%BF%D0%BE%D1%87%D0%BA%D0%B0%20%D0%BE%D0%B1%D1%8F%D0%B7%D0%B0%D0%BD%D0%BD%D0%BE%D1%81%D1%82%D0%B5%D0%B9%20%28Chain%20of%20Responsibility%29.md) (`Chain of Responsibility`) | Передает запрос по цепочке обработчиков, пока кто-то не возьмет его на себя. | [ChainOfResponsibility](https://github.com/zeegin/DesignPatterns/tree/master/ChainOfResponsibility) |
| [Команда](command/%D0%9A%D0%BE%D0%BC%D0%B0%D0%BD%D0%B4%D0%B0%20%28Command%29.md) (`Command`) | Представляет действие как отдельный объект. | [Command](https://github.com/zeegin/DesignPatterns/tree/master/Command) |
| [Интерпретатор](interpreter/%D0%98%D0%BD%D1%82%D0%B5%D1%80%D0%BF%D1%80%D0%B5%D1%82%D0%B0%D1%82%D0%BE%D1%80%20%28Interpreter%29.md) (`Interpreter`) | Описывает грамматику языка и интерпретирует выражения этого языка. |  |
| [Итератор](iterator/%D0%98%D1%82%D0%B5%D1%80%D0%B0%D1%82%D0%BE%D1%80%20%28Iterator%29.md) (`Iterator`) | Дает способ обходить коллекцию, не раскрывая ее внутреннее устройство. | [Iterator](https://github.com/zeegin/DesignPatterns/tree/master/Iterator) |
| [Посредник](mediator/%D0%9F%D0%BE%D1%81%D1%80%D0%B5%D0%B4%D0%BD%D0%B8%D0%BA%20%28Mediator%29.md) (`Mediator`) | Централизует взаимодействие между объектами и уменьшает прямые связи между ними. | [Mediator](https://github.com/zeegin/DesignPatterns/tree/master/Mediator) |
| [Снимок](memento/%D0%A1%D0%BD%D0%B8%D0%BC%D0%BE%D0%BA%20%28Memento%29.md) (`Memento`) | Сохраняет и восстанавливает внутреннее состояние объекта. | [Memento](https://github.com/zeegin/DesignPatterns/tree/master/Memento) |
| [Наблюдатель](observer/%D0%9D%D0%B0%D0%B1%D0%BB%D1%8E%D0%B4%D0%B0%D1%82%D0%B5%D0%BB%D1%8C%20%28Observer%29.md) (`Observer`) | Подписчики получают уведомление об изменении состояния издателя. | [Observer](https://github.com/zeegin/DesignPatterns/tree/master/Observer) |
| [Состояние](state/%D0%A1%D0%BE%D1%81%D1%82%D0%BE%D1%8F%D0%BD%D0%B8%D0%B5%20%28State%29.md) (`State`) | Перекладывает поведение по состояниям в отдельные объекты-состояния. | [State](https://github.com/zeegin/DesignPatterns/tree/master/State) |
| [Стратегия](strategy/%D0%A1%D1%82%D1%80%D0%B0%D1%82%D0%B5%D0%B3%D0%B8%D1%8F%20%28Strategy%29.md) (`Strategy`) | Инкапсулирует взаимозаменяемые алгоритмы за единым интерфейсом. | [Strategy](https://github.com/zeegin/DesignPatterns/tree/master/Strategy) |
| [Шаблонный метод](template-method/%D0%A8%D0%B0%D0%B1%D0%BB%D0%BE%D0%BD%D0%BD%D1%8B%D0%B9%20%D0%BC%D0%B5%D1%82%D0%BE%D0%B4%20%28Template%20Method%29.md) (`Template Method`) | Задает каркас алгоритма, оставляя отдельные шаги на расширение. | [TemplateMethod](https://github.com/zeegin/DesignPatterns/tree/master/TemplateMethod) |
| [Посетитель](visitor/%D0%9F%D0%BE%D1%81%D0%B5%D1%82%D0%B8%D1%82%D0%B5%D0%BB%D1%8C%20%28Visitor%29.md) (`Visitor`) | Выносит операции над структурой объектов в отдельный объект-посетитель. | [Visitor](https://github.com/zeegin/DesignPatterns/tree/master/Visitor) |
