---
tags: [v8std, patterns]
---

[Статья на v8std.ru](https://v8std.ru/patterns/gof/interpreter/) · [Оглавление](../../../v8std%20%E2%80%94%20%D0%BD%D0%B0%D1%87%D0%B0%D1%82%D1%8C%20%D0%B7%D0%B4%D0%B5%D1%81%D1%8C.md)

# Интерпретатор (`Interpreter`)

`Interpreter` описывает грамматику небольшого языка и выполняет выражения этого языка над заданным контекстом.

## Опора на ООП

`Interpreter` опирается на [полиморфизм и композицию](../../principles/%D0%9F%D1%80%D0%B8%D0%BD%D1%86%D0%B8%D0%BF%D1%8B%20%D0%9E%D0%9E%D0%9F.md): каждое выражение реализует общий контракт интерпретации, а сложные выражения собираются из более простых.

## Что показывает пример на 1С

- `EqualsStatusExpression` и `AmountGreaterExpression` интерпретируют простые правила над одним и тем же контекстом.
- `AndExpression` собирает из них составное выражение.
- Клиент работает уже не с длинным `Если`, а с объектным представлением простого DSL.

## Пример

**DataProcessors.Application**

```bsl
Context = New Structure;
Context.Insert("Status", "Ready");
Context.Insert("Amount", 1500);

StatusExpression = DataProcessors.EqualsStatusExpression.Create();
StatusExpression.Init("Ready");

AmountExpression = DataProcessors.AmountGreaterExpression.Create();
AmountExpression.Init(1000);

Rule = DataProcessors.AndExpression.Create();
Rule.Init(StatusExpression, AmountExpression);

If Rule.Interpret(Context) Then
    Message("Rule matched");
EndIf;
```

**DataProcessors.EqualsStatusExpression**

```bsl
Var ExpectedStatus;

#Region Public

Procedure Init(ExpectedStatus_) Export

    ExpectedStatus = ExpectedStatus_;

EndProcedure

Function Interpret(Context) Export

    Return Context.Get("Status") = ExpectedStatus;

EndFunction

#EndRegion
```

**DataProcessors.AmountGreaterExpression**

```bsl
Var Limit;

#Region Public

Procedure Init(Limit_) Export

    Limit = Limit_;

EndProcedure

Function Interpret(Context) Export

    Return Context.Get("Amount") > Limit;

EndFunction

#EndRegion
```

**DataProcessors.AndExpression**

```bsl
Var LeftExpression;
Var RightExpression;

#Region Public

Procedure Init(LeftExpression_, RightExpression_) Export

    LeftExpression = LeftExpression_;
    RightExpression = RightExpression_;

EndProcedure

Function Interpret(Context) Export

    Return LeftExpression.Interpret(Context)
        And RightExpression.Interpret(Context);

EndFunction

#EndRegion
```

## Где полезен в 1С

- для небольших DSL правил, фильтров и формул;
- для интерпретации настроек маршрутов, условий скидок и выражений отбора;
- когда предметная область уже оперирует собственным маленьким языком.

## Когда паттерн лишний

- если правило проще записать обычным кодом;
- если язык быстро становится слишком большим и требует полноценного парсера;
- если объектная модель выражений сложнее самой задачи.
