---
tags: [v8std, patterns]
---

[Статья на v8std.ru](https://v8std.ru/patterns/gof/decorator/) · [Оглавление](../../../v8std%20%E2%80%94%20%D0%BD%D0%B0%D1%87%D0%B0%D1%82%D1%8C%20%D0%B7%D0%B4%D0%B5%D1%81%D1%8C.md)

# Декоратор (`Decorator`)

`Decorator` добавляет объекту новое поведение через обертку, не меняя исходную реализацию.

## Опора на ООП

`Decorator` опирается на [интерфейсы, композицию и полиморфизм](../../principles/%D0%9F%D1%80%D0%B8%D0%BD%D1%86%D0%B8%D0%BF%D1%8B%20%D0%9E%D0%9E%D0%9F.md): декоратор реализует тот же контракт, что и оборачиваемый компонент, и делегирует ему базовую работу, добавляя свой слой поведения.

## Что показывает пример на 1С

- `CommonModules.HttpSender` реализует базовую отправку запроса.
- `LoggingSenderDecorator` и `RetrySenderDecorator` оборачивают отправителя и добавляют логирование и повторные попытки.
- Клиент собирает нужную цепочку поведения без изменения исходного отправителя.

## Пример

**DataProcessors.Application**

```bsl
Sender = CommonModules.HttpSender;

SenderWithLog = DataProcessors.LoggingSenderDecorator.Create();
SenderWithLog.Init(Sender);

SenderWithRetry = DataProcessors.RetrySenderDecorator.Create();
SenderWithRetry.Init(SenderWithLog);

Response = SenderWithRetry.Send(Request);
```

**CommonModules.HttpSender**

```bsl
Function Send(Request) Export

    Return Request.Body;

EndFunction
```

**DataProcessors.LoggingSenderDecorator**

```bsl
Var Component;

#Region Public

Procedure Init(Component_) Export

    Component = Component_;

EndProcedure

Function Send(Request) Export

    WriteLogEvent("Integration", EventLogLevel.Information, , , "Sending request");
    Return Component.Send(Request);

EndFunction

#EndRegion
```

**DataProcessors.RetrySenderDecorator**

```bsl
Var Component;

#Region Public

Procedure Init(Component_) Export

    Component = Component_;

EndProcedure

Function Send(Request) Export

    For Counter = 1 To 3 Do
        Try
            Return Component.Send(Request);
        Except
        EndTry;
    EndDo;

    Raise "Request failed";

EndFunction

#EndRegion
```

## Близость к Proxy

`Decorator` очень похож на [Proxy](../proxy/%D0%97%D0%B0%D0%BC%D0%B5%D1%81%D1%82%D0%B8%D1%82%D0%B5%D0%BB%D1%8C%20%28Proxy%29.md), потому что оба паттерна строятся как обертка вокруг компонента с тем же контрактом.

Из-за этого их легко спутать:

- и там, и там есть внутренний компонент;
- и там, и там вызов проходит через дополнительный слой;
- и клиент часто не видит разницы по сигнатуре методов.

Но смысл различается.

- `Decorator` наращивает поведение;
- `Proxy` контролирует доступ, создание или способ обращения к объекту.

Поэтому для 1С полезно разделять их по намерению:

- если слой добавляет логирование, ретраи, метрики или кэш вокруг вызова, это обычно `Decorator`;
- если слой проверяет права, скрывает удаленный вызов или лениво создает тяжелый объект, это обычно `Proxy`.

## Где полезен в 1С

- для логирования, кэширования, ретраев и профилирования вокруг сервиса;
- для постепенного наращивания технического поведения без переписывания базовой логики;
- когда один и тот же компонент нужно оборачивать разными комбинациями технических слоев.

## Когда паттерн лишний

- если поведение проще явно вызвать рядом;
- если оберток становится слишком много и цепочка трудно читается;
- если декоратор начинает менять бизнес-смысл исходного компонента.
