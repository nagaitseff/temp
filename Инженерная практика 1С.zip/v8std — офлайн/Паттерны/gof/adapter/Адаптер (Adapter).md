---
tags: [v8std, patterns]
---

[Статья на v8std.ru](https://v8std.ru/patterns/gof/adapter/) · [Оглавление](../../../v8std%20%E2%80%94%20%D0%BD%D0%B0%D1%87%D0%B0%D1%82%D1%8C%20%D0%B7%D0%B4%D0%B5%D1%81%D1%8C.md)

# Адаптер (`Adapter`)

`Adapter` переводит неудобный или устаревший интерфейс в тот контракт, который нужен клиентскому коду.

## Опора на ООП

`Adapter` в первую очередь опирается на [интерфейсы и инкапсуляцию](../../principles/%D0%9F%D1%80%D0%B8%D0%BD%D1%86%D0%B8%D0%BF%D1%8B%20%D0%9E%D0%9E%D0%9F.md): несовместимый контракт прячется внутри адаптера, а наружу отдается ожидаемый API. Полиморфизм появляется, когда адаптер подменяет обычную реализацию по тому же контракту.

## Что показывает пример на 1С

- `CommonModules.Adapter` экспортирует понятный клиенту метод `BeautyMethod2WTF(Parameters)`.
- Внутри адаптер преобразует входные данные через `Convert()`, вызывает `Legacy.WTFMethod(Input, Output)` и потом собирает ответ через `Extract(Output)`.
- Код, который использует адаптер, не знает деталей старого контракта и не размазывает их по системе.

## Пример

**CommonModules.Adapter**

```bsl
#Region Public

Function BeautyMethod2WTF(Parameters) Export

    Input = Convert(Parameters);
    Output = Undefined;

    Legacy.WTFMethod(Input, Output);

    Result = Extract(Output);
    Return Result;

EndFunction

#EndRegion

#Region Private

Function Convert(Parameters)

    Return Parameters;

EndFunction

Function Extract(Output)

    Return Output;

EndFunction

#EndRegion
```

**CommonModules.Legacy**

```bsl
#Region Public

Procedure WTFMethod(Input, Output) Export

    Output = "Shit";

EndProcedure

#EndRegion
```

## Где полезен в 1С

- при оборачивании старых общих модулей с неудачным API;
- при интеграции с внешними компонентами, COM или HTTP-клиентами;
- когда нужно перейти на новый интерфейс без массовой переписи прикладного кода.

## Когда паттерн лишний

- если старый код можно безопасно переделать без слоя совместимости;
- если различия между интерфейсами минимальны;
- если адаптер начинает содержать слишком много бизнес-логики и превращается в фасад или сервис.

## Источник примера

- [zeegin/DesignPatterns: Adapter](https://github.com/zeegin/DesignPatterns/tree/master/Adapter)
