---
tags: [v8std, patterns]
---

[Статья на v8std.ru](https://v8std.ru/patterns/gof/factory-method/) · [Оглавление](../../../v8std%20%E2%80%94%20%D0%BD%D0%B0%D1%87%D0%B0%D1%82%D1%8C%20%D0%B7%D0%B4%D0%B5%D1%81%D1%8C.md)

# Фабричный метод (`Factory Method`)

`Factory Method` делегирует создание конкретного объекта специальному методу.

## Опора на ООП

`Factory Method` классически построен прежде всего на [полиморфизме](../../principles/%D0%9F%D1%80%D0%B8%D0%BD%D1%86%D0%B8%D0%BF%D1%8B%20%D0%9E%D0%9E%D0%9F.md): клиент вызывает общий способ создания, а конкретная реализация сама решает, какой объект вернуть. В этом смысле паттерн напрямую вырастает из идеи полиморфизма.

## Что показывает пример на 1С

- `CommonModules.ClientSpecific` экспортирует `CreateWrapper()` и возвращает `DataProcessors.COMWrapper.Create()`.
- Идея в том, что другой создатель, например для веб-клиента, может вернуть другую обертку при том же клиентском контракте.
- Внешний код просит "создай подходящий wrapper", а не выбирает конкретный `DataProcessor` сам.

## Пример

**CommonModules.ClientSpecific**

```bsl
#Region Public

Function CreateWrapper() Export

    Return DataProcessors.COMWrapper.Create();

EndFunction

#EndRegion
```

**DataProcessors.COMWrapper**

```bsl
#Region Public

Function Init(COMObject) Export

    Return "Transformation";

EndFunction

#EndRegion
```

## Где полезен в 1С

- когда создание зависит от типа клиента или канала интеграции;
- когда нужно изолировать логику выбора конкретной реализации;
- когда важен единый вход для создания однотипных оберток и адаптеров.

## Когда паттерн лишний

- если тип реализации не меняется;
- если выбор делается один раз и проще описывается простым условием;
- если фабричный метод превращается в склад разрозненных `Если`.

## Источник примера

- [zeegin/DesignPatterns: FactoryMethod](https://github.com/zeegin/DesignPatterns/tree/master/FactoryMethod)
