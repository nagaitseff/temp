---
tags: [v8std, patterns]
---

[Статья на v8std.ru](https://v8std.ru/patterns/gof/facade/) · [Оглавление](../../../v8std%20%E2%80%94%20%D0%BD%D0%B0%D1%87%D0%B0%D1%82%D1%8C%20%D0%B7%D0%B4%D0%B5%D1%81%D1%8C.md)

# Фасад (`Facade`)

`Facade` дает простой внешний вход к сложной подсистеме.

## Опора на ООП

`Facade` опирается прежде всего на [инкапсуляцию](../../principles/%D0%9F%D1%80%D0%B8%D0%BD%D1%86%D0%B8%D0%BF%D1%8B%20%D0%9E%D0%9E%D0%9F.md): сложная координация нескольких модулей и объектов прячется за компактным внешним API.

## Что показывает пример на 1С

- `CommonModules.SalesOrderFacade` собирает в одной точке создание документа, заполнение, контроль остатков и проведение.
- Клиентский код вызывает один понятный метод вместо серии обращений к разным подсистемам.
- При этом фасад не отменяет внутренние сервисы, а только упрощает типовой сценарий работы с ними.

## Пример

**DataProcessors.Application**

```bsl
SalesOrder = CommonModules.SalesOrderFacade.CreateAndPost(Partner, Items);
```

**CommonModules.SalesOrderFacade**

```bsl
Function CreateAndPost(Partner, Items) Export

    SalesOrder = Documents.SalesOrder.CreateDocument();

    SalesOrderFilling.FillHeader(SalesOrder, Partner);
    SalesOrderFilling.FillItems(SalesOrder, Items);

    StockControl.CheckAvailability(SalesOrder);

    SalesOrder.Write(DocumentWriteMode.Posting);
    Return SalesOrder;

EndFunction
```

**CommonModules.StockControl**

```bsl
Procedure CheckAvailability(SalesOrder) Export

    // Check stock balances.

EndProcedure
```

## Где полезен в 1С

- для типовых сценариев работы с документами, обменами и расчетами;
- когда внутренняя подсистема состоит из нескольких сервисов и объектов;
- когда внешнему коду нужен короткий и устойчивый API.

## Когда паттерн лишний

- если фасад просто переименовывает один вызов;
- если под фасадом начинает скапливаться вся бизнес-логика системы;
- если разным клиентам нужны слишком разные сценарии и один вход их только запутывает.
