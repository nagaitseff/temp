---
tags: [v8std, patterns]
---

[Статья на v8std.ru](https://v8std.ru/patterns/engineering/separation-of-concerns/) · [Оглавление](../../../v8std%20%E2%80%94%20%D0%BD%D0%B0%D1%87%D0%B0%D1%82%D1%8C%20%D0%B7%D0%B4%D0%B5%D1%81%D1%8C.md)

# Separation of Concerns

`Separation of Concerns` требует разделять разные типы задач по отдельным слоям и контекстам.

## Что означает в 1С

В 1С это обычно означает, что стоит различать:

- форму и UI;
- orchestration сценария;
- доменную логику;
- интеграцию;
- инфраструктурные детали.

Если все это смешано в одном модуле формы или в одном общем модуле, код быстро перестает быть управляемым.

## Пример на 1С

**CommonForms.SalesOrderForm**

```bsl
&AtClient
Procedure PostCommand(Command)

    CommonModules.SalesOrderController.Post(Object.Ref);

EndProcedure
```

**CommonModules.SalesOrderController**

```bsl
Procedure Post(SalesOrderRef) Export

    SalesOrder = SalesOrderRef.GetObject();
    SalesOrderValidation.CheckBeforePosting(SalesOrder);
    SalesOrder.Write(DocumentWriteMode.Posting);

EndProcedure
```

Здесь форма отвечает за UI, контроллер за orchestration, а объект документа и сервисы проверки — за свою часть доменной логики.

## Когда полезен

- в формах с большим количеством действий;
- в интеграционных сценариях;
- в больших прикладных модулях, где все перемешалось.

## Когда применяют неправильно

- когда разделение слоев становится формальным и бесполезным;
- когда между слоями появляется слишком много пустых прокладок;
- когда из-за "чистоты" теряется понимание сквозного сценария.

## Связь с инженерной практикой

- [Структура модуля](../../../%D0%A1%D1%82%D0%B0%D0%BD%D0%B4%D0%B0%D1%80%D1%82%D1%8B/std455%20%E2%80%94%20%D0%A1%D1%82%D1%80%D1%83%D0%BA%D1%82%D1%83%D1%80%D0%B0%20%D0%BC%D0%BE%D0%B4%D1%83%D0%BB%D1%8F.md)
