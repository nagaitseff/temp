---
tags: [v8std, patterns]
---

[Статья на v8std.ru](https://v8std.ru/patterns/grasp/low-coupling/) · [Оглавление](../../../v8std%20%E2%80%94%20%D0%BD%D0%B0%D1%87%D0%B0%D1%82%D1%8C%20%D0%B7%D0%B4%D0%B5%D1%81%D1%8C.md)

# Низкая связанность (`Low Coupling`)

`Low Coupling` требует уменьшать количество и жесткость зависимостей между частями системы.

## Опора на ООП

`Low Coupling` опирается на [интерфейсы, композицию и инкапсуляцию](../../principles/%D0%9F%D1%80%D0%B8%D0%BD%D1%86%D0%B8%D0%BF%D1%8B%20%D0%9E%D0%9E%D0%9F.md): модуль зависит от контракта, а не от устройства конкретной реализации.

## Что показывает пример на 1С

- `PaymentService` зависит от абстрактного шлюза оплаты.
- Конкретный `BankGateway` подставляется снаружи.
- Сервис не вшивает внутрь себя детали конкретного банка или API.

## Пример

**DataProcessors.Application**

```bsl
PaymentService = DataProcessors.PaymentService.Create();
PaymentService.SetGateway(CommonModules.BankGateway);

PaymentService.Pay(InvoiceRef, 1000);
```

**DataProcessors.PaymentService**

```bsl
Var Gateway;

#Region Public

Procedure SetGateway(Gateway_) Export

    Gateway = Gateway_;

EndProcedure

Procedure Pay(InvoiceRef, Amount) Export

    Gateway.Pay(InvoiceRef, Amount);

EndProcedure

#EndRegion
```

**CommonModules.BankGateway**

```bsl
Procedure Pay(InvoiceRef, Amount) Export

    // Bank-specific integration.

EndProcedure
```

## Где полезен в 1С

- при интеграции с банками, API, внешними сервисами и обменами;
- когда реализация инфраструктуры может меняться;
- когда модуль хочется тестировать и заменять без каскадных правок.

## Когда принцип применяют неправильно

- когда интерфейсы вводятся "на всякий случай" без реальной точки изменения;
- когда низкая связанность покупается ценой чрезмерной фрагментации;
- когда ради отвязки скрывается важный смысл предметной области.

## Связь с инженерной практикой

- [Правила создания общих модулей](../../../%D0%A1%D1%82%D0%B0%D0%BD%D0%B4%D0%B0%D1%80%D1%82%D1%8B/std469%20%E2%80%94%20%D0%9F%D1%80%D0%B0%D0%B2%D0%B8%D0%BB%D0%B0%20%D1%81%D0%BE%D0%B7%D0%B4%D0%B0%D0%BD%D0%B8%D1%8F%20%D0%BE%D0%B1%D1%89%D0%B8%D1%85%20%D0%BC%D0%BE%D0%B4%D1%83%D0%BB%D0%B5%D0%B9.md)
